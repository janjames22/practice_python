# TODO-1: Ask the user input
# TODO-2: Save dta into dictionary{name: price}
# TODO-3: Whether if new bids need to be added
# TODO-4: Compare bids in dictionary
import art

print(art.logo)

def find_highest_bidder(bidding_dictionary):
    winner = ""
    highest_bid = 0
    for bidder in bidding_dictionary:
        bid_amount = bidding_dictionary[bidder]
        if bid_amount > highest_bid:
            highest_bid = bid_amount
            winner = bidder
    
    print(f"the winner is {bidder} with the amount of ${highest_bid}.")



bids = {}
continue_bidding = True
while continue_bidding:
    name = input("What is your name?: \n")
    price = int(input("What is your bid?: \n $"))
    bids[name] = price
    should_continue = input("Are there any other bidders? Type 'yes' o 'no'. \n")
    if should_continue == "no":
        continue_bidding = False    
        find_highest_bidder(bids)
    elif should_continue == "yes":
        print("\n" * 20)

