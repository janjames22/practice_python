# #Start with user that need to be verified 
# #and an empty list to hold confirmed users.
unconfirmed_users = ['jordan', 'kobe', 'lebron']
confirmed_users = []


# #Verify each user until there are no more unconfirmed user
# #Move each verified confirmed user to the confirmed user
while unconfirmed_users: 
    current_user = unconfirmed_users.pop()
    print(f"Verifying User: {current_user.title()}")
    confirmed_users.append(current_user)

# #Display all confirmed users
print("\nThe Following users have been confirmed: ")
for confirmed_user in confirmed_users:
    print(confirmed_user.title())


