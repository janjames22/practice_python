rent = input("The only car that is for rent is subaru, do you want it for a try? Yes or No\n")


if rent == ('Yes'):
    print("\nLet me see if I can find the best subaru for you.")
else:
    print("\nThere is nothing we can do for you.")
