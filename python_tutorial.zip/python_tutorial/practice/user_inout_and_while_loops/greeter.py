prompt = "if you tell us who you are, we can personalize the message you see."
prompt += "\nWhat is your first name? "



name = input(prompt)
print(f"\nHello, {name}!")