number = input("What number do you wish to report? \n")
number = int(number)

if number % 10 == 0:
    print(f"\nthat number {number} that you wish to report? then it is divisible by 10. You are good. ")
else:
    print(f"\nthat number {number} that you wish to report? then it is not divisible by 10. You are not good. ")