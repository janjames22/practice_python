number = input("Madam and Sir, may I ask if how many of you in your group? \n")
number = int(number)

if number >= 8:
    print("\nThen you have to wait for other customer to finish.")
else:
    print("\nThe table is ready maam and sir")