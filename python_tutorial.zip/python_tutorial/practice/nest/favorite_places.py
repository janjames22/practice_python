#Step 1 - Create a dictionary
favorite_places = {
    'Alice' : {'Paris', 'New York', 'Rome'},
    'Bob': ['Sydney', 'Berlin'],
    'Charlie' : ['London']
}

#Step 2: Loop through and print
for person, places in favorite_places.items():
    if len(places) > 1:
        print(f"\n{person.title()}'s favorite places are:")
    else:
        print(f"\n{person.title()}'s favorite places is:")

    for place in places:
        print(f"\t{place}")
    print()