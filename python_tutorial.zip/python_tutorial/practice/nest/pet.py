pet1 = {
    'animal_type' : 'dog',
    'owner' : 'alice'
}

pet2 = {
    'animal_type': 'cat', 
    'owner' : 'Bob' 
}

pet3 = {
    'animal_type': 'hamster', 
    'owner' : 'Charlie'
}

#Step 2: Storage them in a list
pets = [pet1, pet2, pet3]

# Step3 : Loop through and print information
for pet in pets: 
    print(f"Animal Type: {pet['animal_type'].title()}")
    print(f"\tOwner: {pet['owner'].title()}\n")