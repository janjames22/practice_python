#Step 1: Create the dictionary 
favorite_numbers = {
    'Alice': [5, 7],
    'Bob' : [13, 42],
    'Charlie' : [2, 8, 15]
}

# Step 2: Loop through and print
for person, numbers in favorite_numbers.items():
    print(f"\n{person}'s favorite numbers are:")

    for number in numbers:
        print(f"- {number}")