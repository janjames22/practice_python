# Step 1: Create the dictionary
cities = {
    'Paris': {
        'country': 'france',
        'population': '2.1 million',
        'fact': 'known for the Eiffel Tower' 
    },
    'New York': {
        'country': 'USA',
        'population': '8.3 million',
        'fact': 'Known as the big apple'  
    },
    'Tokyo': {
        'country': 'Japan',
        'population': '9.2 million',
        'fact': 'Known for its skyscrapers'  
    },

}
# Loop through and print information
for city, info in cities.items():
    print(f"\nThe Name of the City: {city.title()}")
    country = info['country']
    population = info['population']
    fact = info['fact']
    print(f"\tCountry: {country.title()}")
    print(f"\tPopulation: {population.title()}")
    print(f"\tFact: {fact.title()}")
