#Step 1: Create a dictionaries for three people
person1 = {
    'first_name': 'Jan', 
    'last_name' : 'James',
    'location': 'Malacanang',
}

person2 = {
    'first_name': 'Lebron', 
    'last_name' : 'James',
    'location': 'Santa Rosa',
}

person3 = {
    'first_name': 'Bronny', 
    'last_name' : 'James',
    'location': 'Nueva Ecija',
}

#Store them in a list
people = [person1, person2, person3]

# Step 3: Loop through the list and print information
for person in people:
    full_name = f"{person['first_name']} {person['last_name']}"
    location = person['location']
    print(f"Full Name: {full_name.title()} ")
    print(f"Location: {location.title()}\n")