# Start with some designs that need to be printed.
unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

#Simulate printing each design, until none are left.
#Move each design to completed_models after printing.
while unprinted_designs:
    present_design = unprinted_designs.pop()
    print(f"Printing model: {present_design}")
    completed_models.append(present_design)

# Display all completed models. 
print("\n The following models have been printed:")
for completed_model in completed_models:
    print(completed_model)