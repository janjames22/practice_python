#List of messages
messages = [
    "Hello, how are you?",
    "I'm on my way!",
    "Don't forget the meeting at 3PM.",
    "Happy Birthday!",
    "Good night, see you tomorrow."

]

# List to store sent messages
sent_messages = []

# Define the function to send messages
def send_messages(m_list, s_list):
    """Simulate sending each message, until none are left. Move each message to sent_messages after sending."""
    while m_list: # Loop while there are message in the list
        c_message = m_list.pop(0) #Remove the first message in the list.
        print(f"Sending message: {c_message}") # Simulate sending the message
        s_list.append(c_message) #Add the message to the s_message list. 

# Call the function with messages list
send_messages(messages[:], sent_messages)

#Print both list to verify the messages were moved
print("\nOriginal Message List: ", messages)
print("\nSent Messages List:", sent_messages)

