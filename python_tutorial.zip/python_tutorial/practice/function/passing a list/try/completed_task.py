# Original list of tasks
tasks = [
    "Finish the project report",
    "Reply to client emails",
    "Update the website content",
    "Prepare the presentation", 
    "Organize the team meeting"
]

# List to store completed tasks
completed_tasks = []

# Define the function to comp;ete tasks
def complete_tasks(task_list, completed_list):
    """Simulate completeting each task, until none are left. 
    Move each task to completed_task after completing it"""

    while task_list:
        current_task = task_list.pop(0) #Remove the first task from the list
        print(f"Completing the task: {current_task}") # Simulate completing the task
        completed_list.append(current_task) # Move the task to completed_tasks
    
#call the funciton with the task list
complete_tasks(tasks[:], completed_tasks)

# Print both lists to verify the tasks were moved correctly
print("\nOriginal Task List:", tasks)
print("\nCompleted Task list:", completed_tasks)