# Original list of orders
orders = [
    "Order #001: 3 x T-shirts",
    "Order #002: 2 x laptops", 
    "Order #003: 1 x Smartphone", 
    "Order #004: 5 x Headphones",
    "Order #005: 10 x Notebooks"
]

# List to store processed orders
processed_orders = []

# Define the function to process orders
def process_orders(order_list, processed_list):
    """Simulate processing each order, until none are left.
    Move each order to processed_orders after processing."""
    while order_list:
        current_order = order_list.pop(0) # remove the first order from the list
        print(f"Processing {current_order}")# Simulate processing the order
        processed_list.append(current_order) # Move the order to processed_order

# Call the function with the orders list
process_orders(orders[:], processed_orders)

# Print both lists to verify the orders were moved correctly
print("\nOriginal Orders List: ", orders)
print("Processed Orders list: ", processed_orders)
