# Define a list of short text messages
messages = [
    "Hello, how are you?",
    "I'm on my way!",
    "Don't forget the meeting at 3 PM.",
    "Happy Birthday!",
    "Good night, see you tomorrow."
]

# define the function to show messages
def show_messages(message_list):
    """Print each messafge in the list."""
    for message in message_list:
        print(message)

#Call the function with the messages list
show_messages(messages)