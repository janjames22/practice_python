def greet_users(names):
    """Print a simple greeting to each user in the list."""
    for name in names:
        messag = f"Hello, {name.title()}!"
        print(messag)

call_names = ['James', 'Jan', 'Lebron']
greet_users(call_names)
