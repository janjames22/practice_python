def city_country(city_name, country_name):
    """Return a full name, neatly formatted"""
    known_location = (f"{city_name}, {country_name}")
    return known_location.title()

#List to store all known locations
locations = [] 

#This is an infinite loop!
while True: 
    print("\nPlease telll me what city and country do you know: ")
    print("type 'e' to quit.")

    n_city = input("Name of the City: ")
    if n_city == 'e':
        break

    n_country = input("Name of the Country: ")
    if n_country == 'e':
        break 

    customized_location = city_country(n_city, n_country)
    locations.append(customized_location)
    print(f"{customized_location} is a good place to live")

#Summarize and print all locations
if locations: 
    print("\nYou have mentioned the following places:")
    for location in locations:
        print(f"-{location}")

else:
    print("\nNo locations were mentioned.")