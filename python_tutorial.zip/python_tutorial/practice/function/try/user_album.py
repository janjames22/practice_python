def make_album(artist_name, album_title, number_of_songs=None):
    """Build a dictionary describing a music album"""
    album = {
        'artist': artist_name, 
        'title': album_title
    }
    if number_of_songs:
        album['songs'] = number_of_songs
    return album

# Start the input loop
while True: 
    print("\nPlease enter the album's artist and title:")
    print("(type 'e' at any time to exit)")

    artist = input("Artist name: ")
    if artist.lower() == 'e':
        break

    title = input("Album Title: ")
    if title.lower() == 'e':
        break

    # Ask for the number of songs, but it's optional
    songs = input("Number of songs (optional): ")
    if songs.lower() == 'e':
        break
    elif songs.isdigit():
        songs = int(songs) # Convert to integer if it's a valid number
    else: 
        songs = None # If input is empty or invalid, set songs to None

    #Call make_album with the user's input
    album_diction = make_album(artist, title, songs)
    print(f"\nAlbum created: {album_diction}")
    