def make_album(artist_name, album_title, number_of_songs=None):
    """Build a dictionary describing a music album"""
    album = {
        'artist': artist_name, 
        'title': album_title
    }
    if number_of_songs:
        album['songs'] = number_of_songs
    return album

# Testing the function by creating several albums
album1 = make_album('The Beatles', 'Abbey Road')
album2 = make_album('Pink Floyd', 'The Dark Side of the Moon')
album3 = make_album('Nirvana', 'Nevermind')

# Printing the albums to show they are storing information correctly 
print(album1)
print(album2)
print(album3)

# Creating an album with the number of songs specified
album4 = make_album('IV of Spades', 'Mundo', number_of_songs=10)

#Printing the album with the number of songs to verify the functionality of the additional parameter number of songs.
print(album4)