def build_person(first_name, lastname, age=None):
    """Return a dictionary of information about a person"""
    person = {'first': first_name, 'last': lastname}
    if age:
        person['age'] = age
    return person

musician = build_person('jan james', 'graza', age=26) 
print(musician)  