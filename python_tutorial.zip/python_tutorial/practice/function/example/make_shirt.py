def make_shirt(shirt_size, shirt_message):
    """Display information about a pet."""
    print(f"\nThe size of your shirt is {shirt_size}.")
    print(f"Your shirt size is {shirt_size} with a message {shirt_message}.")
   
make_shirt('small', 'there are only two genders')
make_shirt(shirt_message='there are only two genders', shirt_size='small')
