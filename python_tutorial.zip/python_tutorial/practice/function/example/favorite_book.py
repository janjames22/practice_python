def favorite_book(title):
    print(f"My favorite book is {title.title()}, that was sale on fully booked Taguig City")

favorite_book('Alice in Wonderland')