def make_shirt(shirt_size, shirt_message='I Love Python'):
    """Display information about a pet."""
    print(f"\nThe size of your shirt is {shirt_size}.")
    print(f"Your shirt size is {shirt_size} with a message {shirt_message}.")
   
make_shirt('medium')
make_shirt('Large')
