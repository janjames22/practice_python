def describe_city(city, country='Philippines'):
    """Display information about a pet."""
    print(f"\nThe {city} is in {country}")

describe_city('Cabanatuan')
describe_city('taguig')
describe_city('tokyo', country='Japan')

