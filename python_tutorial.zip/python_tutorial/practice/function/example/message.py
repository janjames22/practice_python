def display_message():
    """"Display a simple message"""
    print("Hello everyone, right now I am currently working and learning about functions")

display_message()
