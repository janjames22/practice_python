def greet_user(username):
    """Display a simple greeting"""
    print(f"Helloo, {username.title()}")

greet_user('james')

