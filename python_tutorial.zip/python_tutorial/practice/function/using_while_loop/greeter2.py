def get_formatted(first_name, last_name):
    """Return a full name, neatly formatted"""
    full_name = (f"{first_name} {last_name}")
    return full_name.title()

#This is an infinite loop!
while True:
    print("\nPlease tell me your kups name: ")
    print("enter 'e' at any time to quit")

    f_name = input("First name: ")
    if f_name == 'e':
        break

    l_name = input("Last name: ")
    if f_name == 'e':
        break
    

    customized_name = get_formatted(f_name, l_name)
    print(f"\nHello, {customized_name}!")
