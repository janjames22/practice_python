
alien_color = 'blue'



if 'green' in alien_color:
    print("You just earned 5 points for shooting the alien.")
elif 'yellow' in alien_color:
    print("You just earned 3 points.")
elif 'red' in alien_color: 
    print("You just earned only 1 point.")
else:
    print("Your prediction is wrong.")