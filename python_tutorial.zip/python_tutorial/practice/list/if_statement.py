age = 26 
if age >= 28:
    print("You are old enough to vote!")
    print("Have you registered to vote yet?")

else:
    print("Sorry, you are to young to vote.")
    print("Please register to vote as soon as you turn 18!")