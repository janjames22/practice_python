requested_toppings = ['mushrooms', 'pepperoni']

if 'mushrooms' in requested_toppings:
    print("Adding Mushrooms")
if 'pepperoni' in requested_toppings:
    print("Adding Pepperoni")
if 'extra cheese' in requested_toppings: 
    print("Adding Extra Cheese")

print("\nFinished Making Pizza!")