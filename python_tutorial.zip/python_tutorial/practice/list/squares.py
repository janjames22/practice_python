dishes = ('Applebee', 'Red Lobster', 'California Pizza Kitchen', 'LongHorn Steakhouse', 'Carrabba Italian Grill')
print("Old Restaurant Dishes:")
for dish in dishes:
    print(dish)

dishes = ('TGI Fridays: Cajun Shrimp and Chicken Pasta', 'P.F. Changs: Mongolian Style Beef', 'Golden Corral: A Blue-Plate Tie')
print("\nModified dimensions:")
for dish in dishes:
    print(dish)
