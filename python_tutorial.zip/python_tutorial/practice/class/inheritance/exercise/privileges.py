class Privileges: 
    """A class to store an  admin's privileges."""
    def __init__(self, privileges=[]):
        self.privileges = privileges
    
    def show_privileges(self):
        print("Admin privileges:")
        if self.privileges:
            for privilege in self.privileges:
                print(f"-{privilege}")
        else: 
            print("This admin has no privilege")

class User:
    """A parent class User"""
    def __init__(self, first_name, last_name, age, location):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.location = location
    
    def describe_user(self):
        print(f"\nUser: {self.first_name} {self.last_name}, Age: {self.age}, Location: {self.location}.")
    
    def greet_user(self):
        print(f"Hello, {self.first_name} {self.last_name}\n")

class Admin(User): 
    """A user with administrative privileges."""
    def __init__(self, first_name, last_name, age, location):
        super().__init__(first_name, last_name, age, location)
        self.privileges = Privileges()

    
#Create an instances of a separate privileges class with admin user showing the privileges.
admin_user = Admin('Jan James', 'Graza', 27, 'Malacañang, Santa Rosa, Nueva Ecija')
admin_user.describe_user()
admin_user.greet_user()
admin_user.privileges.privileges = (["can add post", "can delete post", "Can ban user"])
admin_user.privileges.show_privileges() 

