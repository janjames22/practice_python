class User: 
    """A simple attempt to model a user."""
    def __init__(self, first_name, last_name, age, location):
        self.first_name = first_name 
        self.last_name = last_name
        self.age = age
        self.location = location
    
    def describe_user(self):
        print(f"\nUser: {self.first_name} {self.last_name}, Age: {self.age}, Location: {self.location}")
    
    def greet_user(self):
        print(f"Hello, {self.first_name} {self.last_name}!")

class Admin(User):
    "A user with administrative privileges."
    def __init__(self, first_name, last_name, age, location):
        super().__init__(first_name, last_name, age, location)
        self.privileges = []
    
    def show_privileges(self):
        print("Admin privileges: ")
        for privilege in self.privileges:
            print(f"-{privilege}")


#Create an instance of Admin user showing its privileges. 
admin_user = Admin('Jan James', 'Graza', 26, 'Malacañang, Santa Rosa, Nueva Ecija')
admin_user.privileges = (['can add post', 'can delete post', 'can ban user'])
admin_user.show_privileges()



# admin_user = User('Jan James', 'Graza', 27, 'Malacañang, Santa Rosa, Nueva Ecija')
# admin_user.describe_user()
# admin_user.greet_user()