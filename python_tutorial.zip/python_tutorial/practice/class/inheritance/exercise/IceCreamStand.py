class Restaurant:
    """A description for a restaurant"""
    def __init__(self, name, cuisine_type):
        self.name = name
        self.cuisine_type = cuisine_type
        self.number_served = 0
    
    def describe_restaurant(self):
        print(f"Restaurant name: {self.name}")
        print(f"Cuisine type: {self.cuisine_type}")
    
    def open_restaurant(self): 
        print(f"{self.name} is now open!")

    def set_number_served(self, number):
        self.number_served = number

    def increment_number_served(self, increment):
        self.number_served += increment
    
class IceCreamStand(Restaurant): 
    def __init__(self, name, cuisine_type='Ice Cream'):
        """Initialize attributes of the parent class."""
        super(). __init__(name, cuisine_type)
        self.flavors = []
    
    def set_flavors(self, flavors):
        self.flavors = flavors

    def display_flavors(self):
        print("\nWe have the following flavors available")
        for flavor in self.flavors:
            print(f"- {flavor}")

#Create an instance of IceCreamStand
my_ice_cream_stand =IceCreamStand("Sweet Nigga")

# Set the available flavors
my_ice_cream_stand.set_flavors(["Vanilla", "Chocolate", "Strawberry", "Mint", "Cookie Dough"])

# Display the available flavors
my_ice_cream_stand.display_flavors()