def add_to_list(letters):
    letters.append("X")

uppercase = ["A", "B", "C"]

add_to_list(uppercase)

print(uppercase) 