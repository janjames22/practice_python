numbs = [1232, 232, 5434, 563, 56, 8787, 898, 111, 222, 4545, 7676, 78345, 87813767, 6746, 673446, 6543, 99787]
odds = [numb for numb in numbs if numb %2 != 0]
#create a for loop to iterate the numbers
# for numb in numbs:
#     if numb % 2!=0:
#         odds.append(numb)

print(odds)
