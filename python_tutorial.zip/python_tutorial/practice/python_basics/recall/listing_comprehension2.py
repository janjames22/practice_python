nums = [1, 2, 3, 4, 5, 6, 7]

strings = ["intro", "to", "list", "comp"]



# results = []
# for i in nums:
#     i = i * 2
#     print('i', i)
#     results.append(i)
# results = []
# for i in strings:
#     i = i.upper()
#     results.append(i)

results = [i.upper() + " hey" for i in strings]
# results = [i * 3 for i in nums]

print("results:", results)

