class Car:
    """Initialize attributes for class car."""

    def __init__(self, make, model, year, color):
        self.make = make
        self.model = model
        self.year = year
        self.color = color
    
    #Creating Methods for the class Car:
    def drive(self):
        print("\nThis "+self.make+" is driving.")
    
    def stop(self):
        print("This "+self.make+" is stopped.")