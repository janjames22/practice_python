from car import Car

#creating an instances:
car_1 = Car("Chevy","Corvette",2021,"blue")
car_2 = Car("Ford","Mustang",2022,"red")


car_2.drive()
car_2.stop()


