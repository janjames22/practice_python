import random

class ImageDataGenerator:
    def __init__(self, resolution):
        #resolution is a tuple (rows, columns)
        self.resolution = resolution

        #Create a 2D list of random values between 0 and 1
        self.image_data = [[random.uniform(0, 1) for _ in range(self.resolution[1])]
                           for _ in range(self.resolution[0])]
    
    def display_image_data(self):
        #Display the 2D list (image data)
        for row in self.image_data:
            print(row)

# Example usage instance
resolution = (4, 3) # 4 rows, 3 columns 
generator = ImageDataGenerator(resolution)
generator.display_image_data()

