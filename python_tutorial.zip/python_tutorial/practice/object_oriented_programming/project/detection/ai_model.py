import random

class AIModel:
    """
    Ai model for analyzing hypersoectral images.
    """
    def __init__(self, model_name):
        self.model_name = model_name
    
    def preprocess_image(self, image_data):
        """
        Simulates preprocessing the pretrain images
        """
        print("Preprocessing the collected images.")

        #Safeguard for division by zero
        #Create an empty list called preprocessed_data.
        preprocessed_data = []
        for row in image_data:
            max_value = max(row)
            if max_value == 0:
                print("warning: Max value in row is zero, skipping normalization for this row.")
                preprocessed_data.append(row) #Keep row unchanged if max_value is 0
            else:
                preprocessed_data.append([pixel / max_value for pixel in row])
        
        return preprocessed_data
    
    def analyze_image(self, image_data):
        """
        Simulates analyzing the data gathered thru the images captured by hyperspecral camera.
        """
        #preprocess the image first.
        # preprocessed_data = self.preprocess_image(image_data)

        # #Debug output of preprocessed data (can remove or limit in real use)
        # print("preprocessed Data (first row):", preprocessed_data[0])

        #Simulate random risk score for analysis (could bne made deterministic for testing.)
        risk_score = random.uniform(0, 100)
        print(f"Risk Score; {risk_score:.2f}")

        #Analyze the risk score and return appropriate message
        if risk_score > 80:
            return "High Risk of Disease/Pest"
        elif 50 < risk_score <= 80:
            return "Medium Risk of Disease/Pest"
        else:
            return "Low Risk of Disease/Pest"

