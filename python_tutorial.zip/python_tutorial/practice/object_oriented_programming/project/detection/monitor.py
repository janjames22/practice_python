from sensors import UltrasonicSensor, DHTSensor
from camera import HyperspectralCamera
from ai_model import AIModel
from display import TFTLCDisplay

class OnionFieldMonitor: 
    """
    A class that monitors the onion field and early detect pest and diseases using various sensors and AI
    """
    def __init__(self, field_name):
        self.field_name = field_name
        self.ultrasonic_sensor = UltrasonicSensor()
        self.dht_sensor = DHTSensor()
        self.camera = HyperspectralCamera((240, 240))
        self.ai_model = AIModel("YOLO V3")
        self.display = TFTLCDisplay("Onion Monitoring Display")
    
    def monitor_field(self):
        """
        Simulates the process of monitoring the field.
        """
        print(f"\n--- Monitoring Field: {self.field_name} ---")

        # Gather DHT sensor data
        temp, humidity = self.dht_sensor.read_data()

        # Gather Ultrasonic sensor data (distance/obstruction)
        distance = self.ultrasonic_sensor.read_data()

        #Capture and analyze hyperspectral image
        image_data = self.camera.capture_image()
        prediction = self.ai_model.analyze_image(image_data)

        #Display sensor data and AI model prediction
        self.display.display_output(f"Temperature: {temp:.2f} °C, Humdity: {humidity:.2f} %, Distance: {distance} cm.")
        self.display.display_output(f"Disease/Pest Prediction: {prediction}")

        #Decision logic based on prediction
        if "High" in prediction:
            self.display.display_output("ALERT: Immediate action required to protect the onion crop!")
        elif "Medium" in prediction:
            self.display.display_output("WARNING: Monitor the field closely for signs of pests or disease.")
        else:
            self.display.display_output("The onion crop is currently healthy.")