class TFTLCDisplay: 
    """
    A class representing a TFT LCD display for output.
    """
    def __init__(self, display_name):
        self.display_name = display_name
    
    def display_output(self, message):
        """
        Simulates displaying output on the TFT LCD screen.
        """
        print(f"{self.display_name}: {message}")


        