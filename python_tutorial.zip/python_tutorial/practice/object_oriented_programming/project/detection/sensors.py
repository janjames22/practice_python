import random 

class Sensor:
    """A base class for sensors."""
    def __init__(self, name, unit):
        self.name = name
        self.unit = unit

    def read_data(self):
        """Abstract method to be overridden by subclasses or childclasses"""
        raise NotImplementedError("Subclasses must implement read_data()")

class UltrasonicSensor(Sensor):
    """Ultrasonic sensor for distance and obstacle detection."""
    def __init__(self):
        super().__init__(name="Ultrasonic", unit="cm")
        self.min_distance = 2  # minimum measurable distance in cm
        self.max_distance = 10 # maximum measurable distance in cm

    def read_data(self):
        """Simulates reading the distance from the ultrasonic sensor."""
        distance = random.uniform(self.min_distance, self.max_distance)
        print(f"{self.name} Sensor Reading: {distance:.2f} {self.unit} (Distance)")
        return distance

class DHTSensor(Sensor):
    """"DHT Sensor for temperature and humidity detection."""
    def __init__(self):
        super().__init__(name="DHT Sensor", unit="Temperature (°C) / Humidity (%)") 
        self.temp_range = (10, 40) # Simulate temperature range (°C)
        self.humidity_range = (30, 90) #Simulate humidity range (%)
    
    def read_data(self):
        """Simulates reading the temperature and humidity from the DHT sensor."""
        temperature = random.uniform(self.temp_range[0], (self.temp_range[1]))
        humidity = random.uniform(self.humidity_range[0], self.humidity_range[1])
        print(f"{self.name} Sensor Reading: {temperature:.2f} °C / {humidity:.2f} % (Temp/Humdity)")
        return temperature, humidity
    