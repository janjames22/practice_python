# Import Sensor from the relevant file (assuming it's in sensors.py)
import random
from sensors import Sensor

class HyperspectralCamera(Sensor):
    def __init__(self, resolution):
        # Call the Sensor's constructor using super()
        super().__init__(name="Hyperspectral Camera", unit="N/A")
        self.resolution = resolution  # Example: (1024, 1024) width x height

    def capture_image(self):
        """
        Simulates capturing a hyperspectral image.
        """
        print(f"{self.name} capturing image at resolution {self.resolution}...")
        self.image_data = [[random.uniform(0, 1) for _ in range(self.resolution[1])]
                           for _ in range(self.resolution[0])]
        print(f"Image captured with {len(self.image_data)} spectral bands.")
        return self.image_data
