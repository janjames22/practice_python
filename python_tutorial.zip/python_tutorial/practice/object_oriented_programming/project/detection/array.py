def preprocess_image(image_data):
    """
    Simulates preprocessing the hyperspectal image data by normalizing it.
    """
    print("Preprocessing hyperspectral image data...")

    #Find the maximum pixel value in the entire image
    max_pixel = max(max(row) for row in image_data)

    #Normalize eacch pixel value by dividing by the max value
    preprocessed_data = [[round(pixel / max_pixel, 2) for pixel in row] for row in image_data]
    return preprocessed_data

#Example 1: Simple 2x2 image data
image_data_1 = [
    [2, 4],
    [6, 8]
]

# Example 2: A 3x3 image data
image_data_2 = [
    [10, 20, 30],
    [40, 50, 60],
    [70, 80, 90]
]

# Example 3: Larger 3x3 image data
image_data_3 = [
    [5, 10, 15],
    [20, 25, 30],
    [35, 40, 45]
]

#Preprocess each image data example
preprocessed_1 = preprocess_image(image_data_1)
preprocessed_2 = preprocess_image(image_data_2)
preprocessed_3 = preprocess_image(image_data_3)

#Print the preprocessed data
print("Preprocessed Image Data 1:")
print(preprocessed_1)

print("Preprocessed Image Data 2:")
print(preprocessed_2)

print("Preprocessed Image Data 3:") 
print(preprocessed_3)
