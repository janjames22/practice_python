from monitor import OnionFieldMonitor

if __name__ == "__main__":
    #Create the field monitor instance
    field_monitor = OnionFieldMonitor("Ariendo, Bongabon Onion Farm")

    #Start monitoring the field.
    field_monitor.monitor_field()