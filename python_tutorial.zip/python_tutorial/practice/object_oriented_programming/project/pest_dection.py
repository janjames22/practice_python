import random

# Base Class for Sensors
class Sensor:
    """A base representing a generic sensor.""" 
    def __init__(self, name, unit):
        self.name = name 
        self.unit = unit

    def read_data(self):
        """Abstract method that should be overridden by derived sensor classes.""" 
        raise NotImplementedError("Subclasses must implement read_data()")
    
# Ultrasonic Sensor (for distance and obstacle detection)
class UltrasonicSensor(Sensor):
    def __init__(self):
        super().__init__(name="Ultrasonic", unit="cm")
        self.min_distance = 2 # minimum measurable distance in cm
        self.max_distance = 400 # maximum measurable distance in cm
    
    def read_data(self):
        """Simulates reading the distance from the ultrasonic sensor."""
        distance  = random.uniform(self.min_distance, self.max_distance)
        print(f"{self.name} Sensor Reading: {distance:.2f} {self.unit} (Distance)")
        return distance
#DHT Sensor (Temperature and Humidity)
class DHTSensor(Sensor):
    def __init__(self):
        super().__init__(name="DHT11", unit="Temperature (°C) / Humidity (%)")
        self.temp_range = (10, 40) #Simulate temperature range (°C)
        self.humidity_range = (30, 90) # Simulate humidity range (%)
    
    def read_data(self):
        """Simulate reading the temperature and humidity from the DHT sensor"""
        temperature = random.uniform(self.temp_range[0], self.temp_range[1])
        humidity = random.uniform(self.humidity_range[0], self.humidity_range[1])
        print(f"{self.name} Reading: {temperature:.2f} °C/ {humidity:.2f} % (Temp/Humdity)")
        return temperature, humidity

#Hyperspectral Camera (inherits from Sensor)
class HyperspectralCamera(Sensor):
    def __init__(self, resolution):
        super().__init__(self="Hyperspectral Camera", unit="px")
        self.resolution = resolution # Example: (1024, 1024) width and height
    
    def capture_image(self):
        """Simulates capturing a hyperspectral image."""
        print(f"{self.name} capturing image at resolution {self.resolution} pixels.")
        self.image_data = [[random.uniform(0,1) for _ in range(self.resolution[0])]
                           for _ in range(self.resolution[0])]
        print(f"Image captured with {len(self.image_data)} spectral bands.")
        return self.image_data


    

    