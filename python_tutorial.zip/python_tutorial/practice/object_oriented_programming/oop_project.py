from bank_accounts import *

#Create an instance for bankaccounts
# James = BankAccount(10100, "James")
Wonhee = BankAccount(2000, "Wonhee")


# James.get_balance()
# Wonhee.get_balance()

# James.deposit(50000)
# Wonhee.deposit(500)

# James.withdraw(10000)
# James.withdraw(10)

# James.transfer(10000, Wonhee)
# James.transfer(100, Wonhee)

#Create an instances for the new class interestReward for new user Jim.
# Jim = InterestRewardsAcct(1000, "Jim")

# Jim.get_balance()

# #Call the Method deposit for Jim and James
# Jim.deposit(100)
# James.deposit(50)

# #Calling the method for trasfering money to James
# Jim.transfer(100, James)

#Creating instance for New Account for Blaze
Blaze = SavingsAcct(1000, "Blaze")

#Calling the methods
Blaze.get_balance()

Blaze.deposit(100)

Blaze.transfer(1000, Wonhee)