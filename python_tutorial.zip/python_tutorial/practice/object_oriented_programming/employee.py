class Employee:
    
    #Initialize attributes for the class Employee:
    def__init__(self, first, last, pay):
        self.first = first
        self.last = 