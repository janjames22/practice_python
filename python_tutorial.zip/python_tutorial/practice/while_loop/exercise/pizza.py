while True:
    topping = input("Enter a pizza topping (or type 'quit' to finish): ")

    pizza = input(topping)

    if pizza == 'quit':
        print("Finished ordering your pizza!")
        break
    else:
        print(f"adding {topping} to your pizza!")
