infinity_number = 1 

while infinity_number <=1000000:
    print(f"The current number: {infinity_number}")
    infinity_number += 1


