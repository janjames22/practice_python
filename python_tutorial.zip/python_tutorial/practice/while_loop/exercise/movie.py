while True: 
    age = input("Please enter your age(or type 'exit' to quit): ")

    if age.lower() == 'exit':
        print("Exiting the program, Goodbye.")
        break
    
    try:
        age = int(age)

        if age < 3:
            print("The ticket is free")
        elif 3 <= age <= 12:
            print("The ticket is $10.")
        else:
            print("The ticket $15")

    except ValueError:
        print("Please enter a valid age or type 'exit' to quit.")
