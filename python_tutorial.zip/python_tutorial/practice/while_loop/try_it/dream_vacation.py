#Dictionaries to store the responses
responses = {}

#Set the flag to indicate that polling is active
polling_active = True

while polling_active:
    #Prompt for the person's name and their dream vacation
    name = input("\nWhat is your name? ")
    vacation = input("If you could visit one place in the world, where would you go? ")

    #Store response in the dictionary. 
    responses[name] = vacation

    #Find out if anyone else is going to take the poll
    again = input("Would you like to let another person respond? (yes/ no) ")
    if again.lower() == 'no':
        polling_active = False

#Polling is complete, show the results
print("\n---Poll Results ---")
for name, vacation in responses.items():
    print(f"{name.title()} would like to visit {vacation}")

