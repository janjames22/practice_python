#List of sandwich orders
sandwich_orders = ['turkey', 'ham', 'chicken', 'veggie']

#List to hold finished sandwiches
finished_sandwiches = []

#Process each sandwich orders
while sandwich_orders:
    current_sandwich = sandwich_orders.pop()
    print(f"I'm currently working on {current_sandwich} sandwich")
    finished_sandwiches.append(current_sandwich)

#Display all finished sandwiches
print("\nFinished Sandwiches: ")
for sandwich in finished_sandwiches:
    print(f"{sandwich.title()} sandwich")