#List of sandwich orders
sandwich_orders = ['turkey', 'ham', 'chicken', 'pastrami', 'pastrami', 'pastrami']

#List to hold finished sandwiches
finished_sandwiches = []

#Notify that pastrami is out of stock
print("\nSorry, we're out of pastrami today.\n")

#Remove all instances of 'pastrami' from the sandwich_orders list
while 'pastrami' in sandwich_orders:
    sandwich_orders.remove('pastrami')

#Process each sandwich order
while sandwich_orders:
    current_sandwich = sandwich_orders.pop()
    print(f"I'm working your {current_sandwich} sandwich.")
    finished_sandwiches.append(current_sandwich)

#Display all finished sandwiches
print("\nFinished Sandwiches: \n")
for sandwich in finished_sandwiches:
    print(sandwich)