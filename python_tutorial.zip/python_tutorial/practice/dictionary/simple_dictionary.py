alien_0 = {'color': 'green', 'points' : 5}

new_color = alien_0['color']
print(f"You just get the {new_color} color.")
